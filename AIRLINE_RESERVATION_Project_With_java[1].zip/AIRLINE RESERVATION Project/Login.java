import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.event.*;




class  LoginPage extends JDialog
{
	LoginPage(){
		//FOnt
		Font f=new Font("Rockwell",Font.PLAIN,65);
		//header
		JPanel heading;
		heading=new JPanel();
		heading.setBackground(new Color(0,0,0,80));
		

		 heading.setBounds(0,0,600,75);
		 JLabel name=new JLabel("Airline Resrvation");
		
		 name.setForeground(Color.WHITE);
		 name.setFont(f);
		 heading.add(name);
		 

		 //loginpanel
		 JPanel login=new JPanel();
		 login.setLayout(null);
		 login.setSize(100,350);
		 login.setBackground(new Color(0,0,0,80));
		 login.setBounds(100,130,400,350);


		JLabel l1=new JLabel("LOGIN FORM");
		l1.setFont(new Font("Helvetica",Font.BOLD,30));
	     l1.setForeground(Color.WHITE);
         l1.setBounds(100,15,300,40);
		  login.add(l1);

		  JLabel l2=new JLabel(new ImageIcon("user0.jpg"));
         l2.setBounds(60,79,40,43);
		  login.add(l2);


        
          JTextField t1=new JTextField("Enter Your Username");
		 t1.setBounds(98,81,220,38);
		   t1.setFont(new Font("Helvetica",Font.PLAIN,15));
		   
		 login.add(t1);
		t1.setBorder(null);
		 t1.setBackground(new Color(233, 255, 255));
		

        JLabel l3=new JLabel(new ImageIcon("psd0.jpg"));
         l3.setBounds(60,148,40,43);
		  login.add(l3);

		 JPasswordField pw=new JPasswordField("Enter Password");
		  pw.setBounds(98,150,220,38);
		   pw.setFont(new Font("Helvetica",Font.PLAIN,20));
		  pw.setBackground(new Color(233, 255, 255));
		  pw.setBorder(null);
		 login.add(pw);
		 

		 JButton b1=new JButton("Login");
		 b1.setBounds(50,250,100,40);
		
		 login.add(b1);
		  b1.setBackground(new Color(214, 241, 180));

		 JButton b2=new JButton("Reset");
		 b2.setBounds(250,250,100,40);
		b2.setBackground(new Color(214, 241, 180));
		 
		 login.add(b2);

		 Cursor cur=new Cursor(Cursor.HAND_CURSOR);
		 Cursor cur1=new Cursor(Cursor.HAND_CURSOR);
		 b1.setCursor(cur);
		 b2.setCursor(cur1);
		  b1.setBorder(null);
		 
		


		//frame
		setSize(600,600);
		Image icon = Toolkit.getDefaultToolkit().getImage("aqq.png");    
        setIconImage(icon);   
		setTitle("Airline Reservation System");
		setLayout(null);
		setLocationRelativeTo(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		//background
		JLabel background=new JLabel(new ImageIcon("airli.jpg"));
		add(background);
		 background.add(heading);
		 background.add(login);

		 background.setBounds(0,0,600,600);
		 
		
		 
    setVisible(true);

	b1.addActionListener(new ActionListener (){
		public void actionPerformed(ActionEvent e){
			if(e.getSource()==b1){
			String userText;
			String pwdText;
			userText=t1.getText();
			pwdText=pw.getText();
			if(userText.equalsIgnoreCase("prat") && pwdText.equalsIgnoreCase("123")){
							  
							    dispose();
                            MenuPage neww=new  MenuPage();
                                      neww.setVisible(true);
									neww.setExtendedState(6);
									  neww.setResizable(false);
									  neww.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}else{
				JOptionPane.showMessageDialog( background,"Invaild UserName And Password");
				t1.setText("");
				pw.setText("");
			}
			

		}
		
		}
	});

	b2.addActionListener(new ActionListener (){
		public void actionPerformed(ActionEvent e){
			if(e.getSource()==b2){
			t1.setText("");
			pw.setText("");
		}
			}
		});

	//text filed  clear  when mouse clicks the TextField

        t1.addMouseListener(new MouseListener() {
            public void mouseClicked(MouseEvent e) {
                if (e.getButton()==1) {
                    t1.setText("");
                }//1=for left click
				//3 = for right click 
                //2 for middlemouse
            }

             public void mousePressed(MouseEvent e) {
             }
           public void mouseReleased(MouseEvent e) {

            }
            public void mouseEntered(MouseEvent e) {

            }
            public void mouseExited(MouseEvent e) {

            }
        });
     //password filed clear when mouse clicks the  password filed 

		pw.addMouseListener(new MouseListener() {
            public void mouseClicked(MouseEvent e) {
                if (e.getButton()==1) {
                    pw.setText("");
                }//1=for left click
				//3 = for right click 
                //2 for middlemouse
            }

             public void mousePressed(MouseEvent e) {
             }
           public void mouseReleased(MouseEvent e) {

            }
            public void mouseEntered(MouseEvent e) {

            }
            public void mouseExited(MouseEvent e) {

            }
        });

 addWindowListener(new WindowAdapter() {
    @Override
    public void windowClosing(WindowEvent we)
    { 
        String ObjButtons[] = {"Yes","No"};
        int PromptResult = JOptionPane.showOptionDialog(null,"Are you sure you want to exit?","Airline System",JOptionPane.DEFAULT_OPTION,JOptionPane.WARNING_MESSAGE,null,ObjButtons,ObjButtons[1]);
        if(PromptResult==JOptionPane.YES_OPTION)
        {
            System.exit(0);
        }
    }
});

	}
	
	  
	
}
class Login{
	public static void main(String[] args) 
	{
		new LoginPage();
	}

}