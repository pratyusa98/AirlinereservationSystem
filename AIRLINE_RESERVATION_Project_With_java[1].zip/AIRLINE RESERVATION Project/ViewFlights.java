
import javax.swing.*; 
 import java.awt.*;
  import java.awt.event.*;
import java.sql.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.plaf.metal.MetalIconFactory;
import javax.swing.table.DefaultTableModel;
class ViewFlights
{  
   ViewFlights()
    {  
    JFrame f= new JFrame("View Flight"); 
	JLabel image=new JLabel(new ImageIcon("good.jpg"));
	 image.setBounds(0,0,800,600);
	image.setLayout(null);
	f.add(image);
	  
   JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
	   l1=new JLabel("Flight_ID");
	    l1.setBounds(40,50, 100,30);
		 l1.setFont(new Font("Arial",Font.BOLD,15));
		 l1.setForeground(Color.red);
	     l2=new JLabel("Flight_Name");
		  l2.setBounds(40,100, 100,30);
		   l2.setFont(new Font("Arial",Font.BOLD,15));
		 l2.setForeground(Color.red);
		   l3=new JLabel("Source");
		    l3.setBounds(40,150, 100,30);
			 l3.setFont(new Font("Arial",Font.BOLD,15));
		 l3.setForeground(Color.red);
		     l4=new JLabel("Destination");
		      l4.setBounds(400,150, 100,30);
			   l4.setFont(new Font("Arial",Font.BOLD,15));
		 l4.setForeground(Color.red);
		       l5=new JLabel("Departure");
		      l5.setBounds(40,200, 100,30);
			   l5.setFont(new Font("Arial",Font.BOLD,15));
		 l5.setForeground(Color.red);
		     l6=new JLabel("Arrival_Time");
		    l6.setBounds(400,200, 100,30);
			 l6.setFont(new Font("Arial",Font.BOLD,15));
		 l6.setForeground(Color.red);
	   	   l7=new JLabel("Flight_CHARGES");
		  l7.setBounds(40,250, 150,30);
		   l7.setFont(new Font("Arial",Font.BOLD,15));
		 l7.setForeground(Color.red);
		 l8=new JLabel("Date Of Departure");
		l8.setBounds(400,250, 150,30);
		 l8.setFont(new Font("Arial",Font.BOLD,15));
		 l8.setForeground(Color.red);
	  l9=new JLabel("FLIGHT INFO");
      l9.setBounds(300,10, 200,30);
	   l9.setFont(new Font("Arial",Font.BOLD,15));
		 l9.setForeground(Color.red);
	  l10=new JLabel("SEARCH BY NAME LIST");
		l10.setBounds(300,300, 250,30);
		 l10.setFont(new Font("Arial",Font.BOLD,15));
		 l10.setForeground(Color.red);
		
		      image.add(l1);
	               image.add(l2);
	                 image.add(l3);
	                  image.add(l4);
	                   image.add(l5);
	                    image.add(l6);
	                     image.add(l7);
			      image.add(l8);
				  image.add(l9);
				  image.add(l10);


		JTextField t1,t2,t3,t4,t5,t6,t7,t8;
		 t1=new JTextField();  
          t1.setBounds(170,50, 150,30);  
           t2=new JTextField();  
            t2.setBounds(170,100, 150,30);
	         t3=new JTextField();  
              t3.setBounds(170,250, 150,30);
	         t4=new JTextField();  
            t4.setBounds(550,200, 150,30); 
	       t5=new JTextField();  
          t5.setBounds(170,200, 150,30); 
	     t6=new JTextField();  
        t6.setBounds(550,250, 150,30);
		t7=new JTextField();  
            t7.setBounds(170,150, 150,30);
			t8=new JTextField();  
            t8.setBounds(550,150, 150,30);
		
		          image.add(t1);
	               image.add(t2);
	                 image.add(t3);
	                  image.add(t4);
	                   image.add(t5);
	                    image.add(t6);
						 image.add(t7);
						  image.add(t8);

			     JButton n=new JButton("SEARCH_BY_ID");
				  n.setBounds(350,50,150,40);  
                  image.add(n); 
			       JButton m=new JButton("SEARCH_BY_NAME");
				    m.setBounds(350,100,150,40);  
                     image.add(m);
				   JButton b1=new JButton("CLEAR");
				       b1.setBounds(550,75,100,40);  
                      image.add(b1);
		 
			

    f.setSize(800,600);  
    f.setLayout(null);  
    f.setVisible(true);  
	f.setResizable(false);
	f.setLocationRelativeTo(null);

	//table
	 JTable table = new JTable(); 

	 // create a table model and set a Column Identifiers to this model 
        Object[] columns = {"Flight_Id","Flight_NAME","Source","Destination","Depart_time","Arrival_time","Flight Charges","Date Of Depart"};
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columns);
	
    // set the model to the table
        table.setModel(model);

		// create JScrollPane
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(50,350,700, 200);
		pane.setVisible(false);
         image.add(pane);

		 // create an array of objects to set the row data
        Object[] row = new Object[8];


		 // button add row
        m.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ej) {
				if(ej.getSource()==m){
		pane.setVisible(true);
				
             
                 row[0] = t1.getText();
                row[1] = t2.getText();
                row[2] = t7.getText();
				 row[3] = t8.getText();
				 row[4] = t5.getText();
				  row[5] = t4.getText();
				   row[6] = t3.getText();
				    row[7] = t6.getText();
					
				  
				   model.addRow(row);}
				 else{
					 pane.setVisible(false);
				 }
                
               
            }
        });


  //Retrive Data
  n.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent evt)
	{
		
        try{  
			//Load the driver class
        Class.forName("oracle.jdbc.driver.OracleDriver");
		// Create con obj
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","pratyusa"); 
		// Create the stmt obj
		
       Statement st=con.createStatement();
       ResultSet rs=st.executeQuery("Select *  from newflight WHERE FLIGHT_ID="+Integer.parseInt(t1.getText()));
		String s="";
		String o="";
		String y="";
		String z="";
		String i="";
		String q="";
		String w="";
		String d="";
		while(rs.next())
		{
				s=s+"\n"+rs.getString(1);
				o=o+"\n"+rs.getString(2);
				y=y+"\n"+rs.getString(3);
				z=z+"\n"+rs.getString(4);
				i=i+"\n"+rs.getString(5);
				q=q+"\n"+rs.getString(6);
				w=w+"\n"+rs.getString(7);
				d=d+"\n"+rs.getString(8);
		}
		t1.setText(s);
		t2.setText(o);
		t7.setText(y);
		t8.setText(z);
		t5.setText(i);
		t4.setText(q);
		t3.setText(w);
		t6.setText(d);
		
			
       
		con.close();
		
       
		}
    catch( ClassNotFoundException | SQLException p)
    { 
        JOptionPane.showMessageDialog(null,p);
    }
}
	});


	b1.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e){
   
   t1.setText("");
   t2.setText("");
   t3.setText("");
   t4.setText("");
   t5.setText("");
   t6.setText("");
   t7.setText("");
   t8.setText("");
  
	 }
   
   
   });



    } 
	public static void main(String args[])
	{
		new ViewFlights();
	}
    }  