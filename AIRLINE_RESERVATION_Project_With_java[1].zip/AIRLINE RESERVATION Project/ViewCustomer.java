import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.plaf.metal.MetalIconFactory;
import javax.swing.table.DefaultTableModel;

public class ViewCustomer extends JFrame{
    JButton button ;
    JLabel label;
    JTextField jtf,jtf1,jtf2,jtf3,jtf4,jtf5;
    JLabel image=new JLabel(new ImageIcon("s.jpg"));
	 Border border = LineBorder.createGrayLineBorder();
    Icon warnIcon = MetalIconFactory.getTreeComputerIcon();

    public ViewCustomer(){
    super("retrieve image from database in java");
image.setBounds(0,0,1200,600);
	image.setLayout(null);
	add(image);

	 JLabel l1,l2,l3,l4,l5,l6,l7,l8;  
    l1=new JLabel("Customer_ID");  
    l1.setBounds(250,100, 150,30);  
	 l1.setFont(new Font("Arial",Font.BOLD,20));
	l1.setForeground(Color.red);
    l2=new JLabel("Cust_NAME");  
    l2.setBounds(250,150, 200,30);
	 l2.setFont(new Font("Arial",Font.BOLD,20));
	l2.setForeground(Color.red);
	l3=new JLabel("Father_NAME");  
     l3.setBounds(250,200,150,30); 
	  l3.setFont(new Font("Arial",Font.BOLD,20));
	l3.setForeground(Color.red);
	l4=new JLabel("Gender");  
   l4.setBounds(250,250, 100,30);
    l4.setFont(new Font("Arial",Font.BOLD,20));
	l4.setForeground(Color.red);
	l5=new JLabel("D_O_B");  
    l5.setBounds(250,300, 100,30);  
	 l5.setFont(new Font("Arial",Font.BOLD,20));
	l5.setForeground(Color.red);
	l6=new JLabel("Address");  
    l6.setBounds(250,350, 100,30); 
	 l6.setFont(new Font("Arial",Font.BOLD,20));
	l6.setForeground(Color.red);
	l7=new JLabel("CUSTOMER DETAILS");  
    l7.setBounds(300,30, 600,30);
	l7.setForeground(Color.red);
	l7.setFont(new Font("Helvetica",Font.BOLD,30));
	l8=new JLabel("SEARCH_BY_NAME");  
    l8.setBounds(700,200,400,30);
	l8.setForeground(Color.red);
	l8.setFont(new Font("Helvetica",Font.PLAIN,30));
	

	image.add(l1);
	image.add(l2);
	image.add(l3);
	image.add(l4);
	image.add(l5);
	image.add(l6);
	image.add(l7);
	image.add(l8);
	
    
    button = new JButton("SEARCH_BY_ID");
    button.setBounds(700,100,200,30);
    
    jtf = new JTextField();
    jtf.setBounds(390,100, 200,30);  
     jtf1 = new JTextField();
    jtf1.setBounds(390,150, 200,30);
	  jtf2 = new JTextField();
    jtf2.setBounds(390,200, 200,30);  
	  jtf3 = new JTextField();
    jtf3.setBounds(390,300,200,30);
	  jtf4 = new JTextField();
    jtf4.setBounds(390,250, 200,30);  
	  jtf5 = new JTextField();
    jtf5.setBounds(390,350,100,50);

	JButton p=new JButton("SEARCH_BY_NAME");
		 //b.setfont(new Font("Arial",Font.ITALIC,15));
			 p.setSize(20,20);
    p.setBounds(700,150,200,30);  
    image.add(p); 
    
     label = new JLabel();
    label.setBounds(50,140,150,150);
       label.setHorizontalTextPosition(JLabel.LEFT);
    label.setVerticalTextPosition(JLabel.BOTTOM);
    label.setBorder(border);
    image.add(label);

	
	 JTable table = new JTable(); 

	 // create a table model and set a Column Identifiers to this model 
        Object[] columns = {"Customer_ID","Customer_NAME","Father Name","Gendr","DOB","Adress"};
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columns);
	
    // set the model to the table
        table.setModel(model);

		// create JScrollPane
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(600,250,550, 200);
		pane.setVisible(false);
         image.add(pane);

		 // create an array of objects to set the row data
        Object[] row = new Object[7];


		 // button add row
        p.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
				if(e.getSource()==p){
		pane.setVisible(true);
				
             
                 row[0] = jtf.getText();
                row[1] = jtf1.getText();
                row[2] = jtf2.getText();
				 row[3] = jtf4.getText();
				 row[4] = jtf3.getText();
				  row[5] = jtf5.getText();

				   model.addRow(row);}
				 else{
					 pane.setVisible(false);
				 }
                
               
            }
        });
	
    
    image.add(button);
    image.add(label);
    image.add(jtf);
	image.add(jtf1);
	image.add(jtf2);
	image.add(jtf3);
	image.add(jtf4);
	image.add(jtf5);
    
    button.addActionListener(new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {
        
            try{
				 Class.forName("oracle.jdbc.driver.OracleDriver");
                Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","pratyusa"); 
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("select * from MYIMAGES where TEXTID = '"+jtf.getText()+"'");

                if(rs.next()){
					jtf1.setText(rs.getString(2));
					jtf5.setText(rs.getString(3));
					jtf2.setText(rs.getString(6));
					jtf3.setText(rs.getString(7));
					jtf4.setText(rs.getString(5));
                    byte[] img = rs.getBytes("Image");

            

                    //Resize The ImageIcon
                    ImageIcon image = new ImageIcon(img);
					
                    Image im = image.getImage();
                    Image myImg = im.getScaledInstance(label.getWidth(), label.getHeight(),Image.SCALE_SMOOTH);
                    ImageIcon newImage = new ImageIcon(myImg);
                    label.setIcon(newImage);
				
                }
                
                else{
                    JOptionPane.showMessageDialog(null,"No Data Try another ID");
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        
        }
    });
    
    setLayout(null);
   // setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    //getContentPane().setBackground(Color.cyan);
   setSize(1200,600);  
    setLayout(null);  
    setVisible(true); 
	setResizable(false);
	setLocationRelativeTo(null);
    } 
     
    public static void main(String[] args){
        new ViewCustomer();
    }
   }