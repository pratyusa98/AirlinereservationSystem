import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.plaf.metal.MetalIconFactory;
import javax.swing.table.DefaultTableModel;
import java.sql.*;



class TicetReservation  extends JFrame
{  
	  JButton button ;
    JLabel label;
	
   int i = 1;
  int total = 10005;

       
 TicetReservation  ()
	{
		JFrame f= new JFrame(""); 
		JLabel image=new JLabel(new ImageIcon("tickets.jpg"));
	 image.setBounds(0,0,1250,650);
	image.setLayout(null);
	f.add(image);

    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18,l19,l20,l21;
	l19=new JLabel("TICKET RESERVATION");  
    l19.setBounds(500,10,400,30);  
		 l19.setFont(new Font("Arial",Font.BOLD,15));
		 l19.setForeground(Color.red);
	l8=new JLabel("Ticket_Number");  
    l8.setBounds(680,50, 200,30); 
	 l8.setFont(new Font("Arial",Font.BOLD,15));
		 l8.setForeground(Color.red);
    l1=new JLabel("Customer_ID");  
    l1.setBounds(700,100, 100,30);  
	 l1.setFont(new Font("Arial",Font.BOLD,15));
		 l1.setForeground(Color.red);
    l2=new JLabel("Customer_NAME");  
    l2.setBounds(680,150, 200,30);
	 l2.setFont(new Font("Arial",Font.BOLD,15));
		 l2.setForeground(Color.red);
	l3=new JLabel("Father_NAME");  
    l3.setBounds(700,250, 100,30);  
	 l3.setFont(new Font("Arial",Font.BOLD,15));
		 l3.setForeground(Color.red);
	l4=new JLabel("Gender");  
    l4.setBounds(700,200,100,30);  
	 l4.setFont(new Font("Arial",Font.BOLD,15));
		 l4.setForeground(Color.red);
	l5=new JLabel("D_O_B");  
    l5.setBounds(700,300, 100,30);  
	 l5.setFont(new Font("Arial",Font.BOLD,15));
		 l5.setForeground(Color.red);
	l6=new JLabel("Address");  
    l6.setBounds(700,350, 100,30); 
	 l6.setFont(new Font("Arial",Font.BOLD,15));
		 l6.setForeground(Color.red);
	l9=new JLabel("Flight_ID");  
    l9.setBounds(700,430, 100,30); 
	 l9.setFont(new Font("Arial",Font.BOLD,15));
		 l9.setForeground(Color.red);
	l10=new JLabel("Departure Time");
    l10.setBounds(680,480, 200,30); 
	 l10.setFont(new Font("Arial",Font.BOLD,15));
		 l10.setForeground(Color.red);
	l11=new JLabel("Flight_Name");  
    l11.setBounds(700,530, 100,30); 
	 l11.setFont(new Font("Arial",Font.BOLD,15));
		 l11.setForeground(Color.red);
	l12=new JLabel("Flight Charges");
    l12.setBounds(1000,170, 200,30); 
	 l12.setFont(new Font("Arial",Font.BOLD,15));
		 l12.setForeground(Color.red);
	l13=new JLabel("Date_of_JOURNEY");  
    l13.setBounds(1000,230, 150,30); 
	 l13.setFont(new Font("Arial",Font.BOLD,15));
		 l13.setForeground(Color.red);
	l14=new JLabel("Flight_Class");  
    l14.setBounds(1000,290, 150,30); 
	 l14.setFont(new Font("Arial",Font.BOLD,15));
		 l14.setForeground(Color.red);
	l15=new JLabel("Seats");  
    l15.setBounds(1000,350, 150,30);
	 l15.setFont(new Font("Arial",Font.BOLD,15));
		 l15.setForeground(Color.red);
	l16=new JLabel("Amount");  
    l16.setBounds(1000,410, 150,30);
	 l16.setFont(new Font("Arial",Font.BOLD,15));
		 l16.setForeground(Color.red);
	l17=new JLabel("SOURCE");  
    l17.setBounds(10,50, 80,30);
	 l17.setFont(new Font("Arial",Font.BOLD,15));
		 l17.setForeground(Color.red);
	l18=new JLabel("DESTINATION");  
    l18.setBounds(250,50, 130,30);
	 l18.setFont(new Font("Arial",Font.BOLD,15));
		 l18.setForeground(Color.red);
	l20=new JLabel("Select Flight From List Given Below");  
    l20.setBounds(200,100, 400,30);
	 l20.setFont(new Font("Arial",Font.BOLD,15));
		 l20.setForeground(Color.red);
	l21=new JLabel("Search By Name List");  
    l21.setBounds(250,350, 400,30);
	 l21.setFont(new Font("Arial",Font.BOLD,15));
		 l21.setForeground(Color.red);
	
	
	
	
     image.add(l1);
	 image.add(l2);
	 image.add(l3);
	 image.add(l4);
	 image.add(l5);
	 image.add(l6);
	 image.add(l8);
	 image.add(l9);
	 image.add(l10);
	 image.add(l11);
	 image.add(l12);
	 image.add(l13);
	 image.add(l14);
	 image.add(l15);
	 image.add(l16);
	 image.add(l17);
	 image.add(l18);
	 image.add(l19);
	 image.add(l20);
	 image.add(l21);
	

	
    JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14; 
	 t5=new JTextField(""+ total);  
    t5.setBounds(810,50,150,25);  
    t1=new JTextField("");  
    t1.setBounds(810,100, 150,25);  
    t2=new JTextField("");  
    t2.setBounds(810,150, 150,25);
	 t3=new JTextField("");  
    t3.setBounds(810,250, 150,25);
	 t4=new JTextField("");  
    t4.setBounds(810,300, 150,25);  
	 t6=new JTextField("");  
    t6.setBounds(810,430, 150,25);  
	 t7=new JTextField("");  
    t7.setBounds(810,480, 150,25);  
	 t8=new JTextField("");  
    t8.setBounds(810,530, 150,25);  
	 t9=new JTextField("");  
    t9.setBounds(1000,200, 150,25);  
	 t10=new JTextField("");  
    t10.setBounds(1000,260, 150,25);  
	 t11=new JTextField("");  
    t11.setBounds(1000,320, 150,25); 
	t12=new JTextField("");  
    t12.setBounds(1000,380, 150,25); 
	t13=new JTextField("");  
    t13.setBounds(1000,440, 150,25); 
	t14=new JTextField(""); 
    t14.setBounds(790,200,100,30);    

	     
       JTextArea area=new JTextArea();
		 
		  JScrollPane stxt = new JScrollPane(area);  
	
      stxt.setBounds(810,350,150,70);  
      image.add(stxt);  
		
		 JButton a=new JButton("SEARCH");
		 //b.setfont(new Font("Arial",Font.ITALIC,15));
			 a.setSize(20,20);
    a.setBounds(1000,50,200,30);  
    image.add(a); 
	 JButton p=new JButton("SEARCH_BY_NAME");
		 //b.setfont(new Font("Arial",Font.ITALIC,15));
			 p.setSize(20,20);
    p.setBounds(1000,130,200,30);  
    image.add(p); 
	JButton b=new JButton("BOOK");
		 //b.setfont(new Font("Arial",Font.ITALIC,15));
			
    b.setBounds(1000,500,150,50);  
    image.add(b); 
	JButton m=new JButton("SHOW");
		 //b.setfont(new Font("Arial",Font.ITALIC,15));
			
    m.setBounds(560,55,100,20);  
    image.add(m); 


	
    
  

  

      
    image.add(t1);
	image.add(t2);
	image.add(t3);
	image.add(t4);
	image.add(t5);
	image.add(t6);
	image.add(t7);
	image.add(t8);
	image.add(t9);
	image.add(t10);
	image.add(t11);
	image.add(t12);
	image.add(t13);
     image.add(t14);
	 
    
    

	 Choice c=new Choice();
	   Choice v=new Choice();
	    c.setBounds(85,55,150,30);
		 c.add("Select");
		  c.add("BBSR");
		  c.add("BANGALORE");
		  c.add("KOLKATA");
		  c.add("DELHI");
		  c.add("MUMBAI");
		  c.add("HYDRABAD");
		  c.add("LUKHNOW");
		  c.add("AHMEDABAD");
		  c.add("SRINAGAR");
		  c.add("USA");
		  c.add("UAE");
		   image.add(c);
		   v.setBounds(390,55, 150,30);
		    v.add("Select");
          v.add("BBSR");
		  v.add("DUBAI");
		  v.add("CANADA");
		   v.add("GOA");
           v.add("CHANNAI");
		    v.add("JAIPUR");
		   v.add("AMRITSAR");
		    v.add("AUSTRILIA");
			 v.add("SOUTHAFRIKA");
			  v.add("CALIFORNIA");
		   image.add(v);

	
	
   
	
    f.setSize(1250,650);  
    f.setLayout(null);  
    f.setVisible(true); 
	f.setResizable(false);
	f.setLocationRelativeTo(null);


//JTAble 2
 JTable table1 = new JTable(); 

	 // create a table model and set a Column Identifiers to this model 
        Object[] columns1 = {"Customer_ID","Customer_NAME","Father Name","Gendr","DOB","Adress"};
        DefaultTableModel model1 = new DefaultTableModel();
        model1.setColumnIdentifiers(columns1);
	
    // set the model to the table
        table1.setModel(model1);

		// create JScrollPane
        JScrollPane pane1 = new JScrollPane(table1);
        pane1.setBounds(20,400,650, 200);
		pane1.setVisible(false);
          image.add(pane1);

		 // create an array of objects to set the row data
        Object[] row1 = new Object[7];


		 // button add row
        p.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
				if(e.getSource()==p){
		pane1.setVisible(true);
				
             
                 row1[0] = t1.getText();
                row1[1] = t2.getText();
                row1[2] = t3.getText();
				row1[3] = t14.getText();
				 row1[4] = t4.getText();
				  row1[5] =  area.getText();

				  

				   model1.addRow(row1);}
				 else{
					 pane1.setVisible(false);
				 }
                
               
            }
        });
		



	//Jtable 1
	//table
	 JTable table = new JTable(); 

	 // create a table model and set a Column Identifiers to this model 
        Object[] columns = {"Flight_Id","Flight_NAME","Depart_time","Flight Charges","Date Of Depart"};
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columns);
	
    // set the model to the table
        table.setModel(model);

		// create JScrollPane
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(10,145,650, 200);
		pane.setVisible(false);
          image.add(pane);

		 // create an array of objects to set the row data
        Object[] row = new Object[5];


		 // button add row
        m.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ek) {
				if(ek.getSource()==m){
					
			
			 pane.setVisible(false);
			
			 try{  
			//Load the driver class
        Class.forName("oracle.jdbc.driver.OracleDriver");
		// Create con obj
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","pratyusa"); 
		// Create the stmt obj
		 Statement st=con.createStatement();
       ResultSet rs=st.executeQuery("Select * from newflight");
		String s="";
		String o="";
		String y="";
		String z="";
		String i="";
		
		while(rs.next())
		{
				s=rs.getString(1);
				o=rs.getString(2);
				y=rs.getString(5);
				z=rs.getString(7);
				i=rs.getString(8);
				
		}
		

		model.addRow(new Object[]{s,o,y,z,i});
		
			
       
		con.close();
		pane.setVisible(true);
       
		}
    catch( ClassNotFoundException | SQLException e)
    { 
        JOptionPane.showMessageDialog(null,e);
    }
                
				  }
				 else{
					 pane.setVisible(false);
				 }
                 }
        });

		//show selected row in jtextfield
		table.addMouseListener(new MouseAdapter(){
        
        @Override
        public void mouseClicked(MouseEvent e){
            
            // i = the index of the selected row
            int i = table.getSelectedRow();
            
            t6.setText(model.getValueAt(i, 0).toString());
            t8.setText(model.getValueAt(i, 1).toString());
          t7.setText(model.getValueAt(i, 2).toString());
            t9.setText(model.getValueAt(i, 3).toString());
			t10.setText(model.getValueAt(i, 4).toString());
        }
        });

		//search button

		a.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent ett)
	{
		
        try{  
			//Load the driver class
        Class.forName("oracle.jdbc.driver.OracleDriver");
		// Create con obj
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","pratyusa"); 
		// Create the stmt obj
		
       Statement st=con.createStatement();
       ResultSet rs=st.executeQuery("Select *  from MYIMAGES WHERE TEXTID="+Integer.parseInt(t1.getText()));
		String s="";
		String o="";
		String y="";
		String z="";
		String i="";
		String l="";
		
		if(rs.next())
		{
				s=s+"\n"+rs.getString(1);
				o=o+"\n"+rs.getString(2);
				y=y+"\n"+rs.getString(6);
				z=z+"\n"+rs.getString(7);
				i=i+"\n"+rs.getString(3);
				l=rs.getString(5);

				
          
			
		 
		
		}
		else{
		 JOptionPane.showMessageDialog(null,"No Data Try another ID");
		}
		t1.setText(s);
		t2.setText(o);
		t3.setText(y);
		t4.setText(z);
		area.setText(i);
		t14.setText(l);
		
			
       
		con.close();
		
        

		}
    catch( ClassNotFoundException | SQLException p)
    { 
        JOptionPane.showMessageDialog(null,p);
    }
}
	});


	

		//add action listener for book button
	b.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent evt)
	{
		
        try{  
			//Load the driver class
        Class.forName("oracle.jdbc.driver.OracleDriver");
		// Create con obj
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","pratyusa"); 
		// Create the stmt obj
		
        PreparedStatement ps=con.prepareStatement("insert into TICKETRESERVATION values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"); 
        ps.setString(1, t5.getText());
		 ps.setString(2, t1.getText());
		 ps.setString(3, t2.getText()); 
		ps.setString(4, area.getText());
        ps.setString(5, t6.getText());
        ps.setString(6, t8.getText());
          ps.setString(7, t9.getText());
		    ps.setString(8, t10.getText());
			 ps.setString(9, t11.getText());

		    ps.setString(10, t12.getText());
		    ps.setString(11, t13.getText());
			 ps.setString(12, t3.getText());

			  ps.setString(14, t4.getText());
			 ps.setString(15, t7.getText());
			 ps.setString(13,t14.getText());

			
			 
			   
			 
				   
		   
			
       
			
        ps.executeUpdate();
		ps.close();
		con.close();
		
        JOptionPane.showMessageDialog(null,"Data Registered... Now Pay For Reservation ");
		}
    catch( ClassNotFoundException | SQLException p)
    { 
        JOptionPane.showMessageDialog(null,p);
    }
}
	});

	

	}
	

public static void main(String args[])  
    {  
	new TicetReservation  ();
    }  
}    
