import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.*;
import java.io.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.plaf.metal.MetalIconFactory;


 class AddCustomer extends JFrame{
    JButton button ;
    JButton button2;
    JLabel label;
	JLabel image=new JLabel(new ImageIcon("06.jpg"));
	Border border = LineBorder.createGrayLineBorder();
    Icon warnIcon = MetalIconFactory.getTreeComputerIcon();
   
    JTextArea area;
    FileInputStream s;

	 int i = 1;
  int total = 100;
     
    AddCustomer(){
   
    super("ADD Customer");
    image.setBounds(0,0,800,600);
	image.setLayout(null);
	add(image);

	 JLabel l1,l2,l3,l4,l5,l6,l7;  
    l1=new JLabel("Customer_ID");  
    l1.setBounds(50,100, 200,30);  
    l1.setFont(new Font("Arial",Font.BOLD,20));
	l1.setForeground(Color.red);
    l2=new JLabel("Cust_NAME");  
    l2.setBounds(50,150, 200,30);
	l2.setFont(new Font("Arial",Font.BOLD,20));
	l2.setForeground(Color.red);
	l3=new JLabel("Father_NAME");  
    l3.setBounds(50,250, 150,30);
	l3.setFont(new Font("Arial",Font.BOLD,20));
	l3.setForeground(Color.red);
	l4=new JLabel("Gender");  
    l4.setBounds(50,200,100,30);  
	l4.setFont(new Font("Arial",Font.BOLD,20));
	l4.setForeground(Color.red);
	l5=new JLabel("D_O_B");  
    l5.setBounds(50,300, 100,30); 
	l5.setFont(new Font("Arial",Font.BOLD,20));
	l5.setForeground(Color.red);
	l6=new JLabel("Address");  
    l6.setBounds(50,400, 100,30); 
	l6.setFont(new Font("Arial",Font.BOLD,20));
	l6.setForeground(Color.red);
	l7=new JLabel("CUSTOMER DETAILS");  
    l7.setBounds(230,30, 600,30);
	l7.setFont(new Font("Helvetica",Font.PLAIN,20));
	
    image.add(l1);
	image.add(l2);
	image.add(l3);
	image.add(l4);
	image.add(l5);
	image.add(l6);
	image.add(l7);

	JTextField t1,t2,t3,t4,t5;  
    t1=new JTextField("" + total);  
    t1.setBounds(200,100, 200,30);  
    t2=new JTextField("");  
    t2.setBounds(200,150, 200,30);
	 t3=new JTextField("");  
    t3.setBounds(200,250, 200,30);
	 t4=new JTextField("");  
    t4.setBounds(200,300, 200,30); 
	t5=new JTextField("");  
    t5.setBounds(200,200,200,30);

	 image.add(t1);
	image.add(t2);
	image.add(t3);
	image.add(t4);
	image.add(t5);
    
    button = new JButton("SAVE");
    button.setBounds(500,400,100,30);  
    
    button2 = new JButton("Browse");
    button2.setBounds(550,270,150,30); 
    
   

    area = new JTextArea("",50, 50);
    
    JScrollPane pane = new JScrollPane(area);
    pane.setBounds(150,400,250,100);  
    
    label = new JLabel();  
	 label.setHorizontalTextPosition(JLabel.LEFT);
    label.setVerticalTextPosition(JLabel.BOTTOM);
    label.setBorder(border);
    label.setBounds(550,100,150,150);
  
    //button to browse the image into jlabel
   	button2.addActionListener(new ActionListener() {
		 public void actionPerformed(ActionEvent e) {
        
          JFileChooser file = new JFileChooser();
		  try
		  {
			file.setCurrentDirectory(new File(System.getProperty("user.home")));
			//filter the files
			FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", "jpg","gif","png");
			file.addChoosableFileFilter(filter);
			int result = file.showSaveDialog(null);
			//if the user click on save in Jfilechooser
			if(result == JFileChooser.APPROVE_OPTION){
              File selectedFile = file.getSelectedFile();
              String path = selectedFile.getAbsolutePath();
              label.setIcon(ResizeImage(path));
			   s=new FileInputStream(path);
			}
			//if the user click on save in Jfilechooser
			else if(result == JFileChooser.CANCEL_OPTION){
              System.out.println("No File Select");
			}
			}
		  catch (FileNotFoundException f)
		  {
				JOptionPane.showMessageDialog(null,"File Not Found");
		  }}});

    //button to insert image and some data into mysql database
    button.addActionListener(new ActionListener(){
    
       @Override
       public void actionPerformed(ActionEvent e){
           try{
			    Class.forName("oracle.jdbc.driver.OracleDriver");
               Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","pratyusa"); 
			   PreparedStatement ps=con.prepareStatement("insert into myimages values (?,?,?,?,?,?,?)");  
            
             
               ps.setString(1, t1.getText());
               ps.setString(2, t2.getText());
               ps.setString(3, area.getText());
               ps.setBinaryStream(4,s,s.available());
			   ps.setString(5, t5.getText());
			   ps.setString(6, t3.getText());
			    ps.setString(7, t4.getText());
               ps.executeUpdate();
              JOptionPane.showMessageDialog(null,"File Saved ");
        JOptionPane.showMessageDialog(null,"Customer Deatailed Submited ");
               total += i;
	  t1.setText("" + total);
	  t2.setText("");
		t3.setText("");
		t4.setText("");
		t5.setText("");
		area.setText("");
           }catch(ClassNotFoundException | SQLException | IOException  ex){
               //ex.printStackTrace();
			   JOptionPane.showMessageDialog(null,ex);
           }
       }
    });

    image.add(label);
    
    image.add(pane);
    image.add(button);
    image.add(button2);
     setSize(800,600);  
    setLayout(null);  
    setVisible(true); 
	setResizable(false);
	setLocationRelativeTo(null);
    }
    
    //Methode To Resize The ImageIcon
    public ImageIcon ResizeImage(String imgPath){
        ImageIcon MyImage = new ImageIcon(imgPath);
        Image img = MyImage.getImage();
        Image newImage = img.getScaledInstance(label.getWidth(), label.getHeight(),Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImage);
        return image;
    }
 
    public static void main(String[] args){
        new AddCustomer();
    }
   }