
import javax.swing.*; 
import java.awt.*;
import java.sql.*;
import java.awt.event.*;

class NewFlight extends JFrame 
{  
	  int i = 1;
  int total = 4007;
   NewFlight()
    {  
    JFrame f= new JFrame("Label Example");
	JLabel image=new JLabel(new ImageIcon("goodwp.jpg"));
	 image.setBounds(0,0,800,500);
	image.setLayout(null);
	f.add(image);
	   Choice c=new Choice();
	   Choice b=new Choice();
		  c.setBounds(150,155, 150,30);
		   c.add("Select Source");
		  c.add("BBSR");
		  c.add("BANGALORE");
		  c.add("KOLKATA");
		  c.add("DELHI");
		  c.add("MUMBAI");
		  c.add("HYDRABAD");
		  c.add("LUKHNOW");
		  c.add("AHMEDABAD");
		  c.add("SRINAGAR");
		  c.add("USA");
		  c.add("UAE");
		  image.add(c);
		   b.setBounds(550,155, 150,30);
		    b.add("Select Destination");
		  b.add("BBSR");
		  b.add("DUBAI");
		  b.add("CANADA");
		   b.add("GOA");
           b.add("CHANNAI");
		    b.add("JAIPUR");
		   b.add("AMRITSAR");
		    b.add("AUSTRILIA");
			 b.add("SOUTHAFRIKA");
			  b.add("CALIFORNIA");
		 image.add(b);
   JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9;
	   l1=new JLabel("Flight_ID");
	    l1.setBounds(40,100, 100,30);
		 l1.setFont(new Font("Arial",Font.BOLD,15));
		 l1.setForeground(Color.red);
	     l2=new JLabel("Fligt_Name");
		  l2.setBounds(450,100, 100,30);
		   l2.setFont(new Font("Arial",Font.BOLD,15));
		   l2.setForeground(Color.red);
		   l3=new JLabel("Source");
		    l3.setBounds(40,150, 100,30);
			 l3.setFont(new Font("Arial",Font.BOLD,15));
			 l3.setForeground(Color.red);
		     l4=new JLabel("Destination");
		      l4.setBounds(450,150, 100,30);
			   l4.setFont(new Font("Arial",Font.BOLD,15));
			   l4.setForeground(Color.red);
		       l5=new JLabel("Departure_Time");
		      l5.setBounds(30,200, 200,30);
			   l5.setFont(new Font("Arial",Font.BOLD,15));
			   l5.setForeground(Color.red);
		     l6=new JLabel("Arrival_Time");
		    l6.setBounds(450,200, 200,30);
			 l6.setFont(new Font("Arial",Font.BOLD,15));
			 l6.setForeground(Color.red);
	   	   l7=new JLabel("Flight_CHARGES");
		  l7.setBounds(20,250, 200,30);
		   l7.setFont(new Font("Arial",Font.BOLD,15));
		   l7.setForeground(Color.red);
		 l8=new JLabel("Date_Of_Departure");
		l8.setBounds(400,250, 250,30);
		 l8.setFont(new Font("Arial",Font.BOLD,15));
		 l8.setForeground(Color.red);
		l9=new JLabel("ADD NEW FLIGHTS");  
    l9.setBounds(250,30, 600,30);
	l9.setFont(new Font("Helvetica",Font.PLAIN,30));
	l9.setForeground(Color.red);
			      image.add(l1);
	               image.add(l2);
	                 image.add(l3);
	                  image.add(l4);
	                   image.add(l5);
	                    image.add(l6);
	                     image.add(l7);
						  image.add(l8);
						   image.add(l9);

		JTextField t1,t2,t3,t4,t5,t6;
		 t1=new JTextField(""+ total);  
          t1.setBounds(150,100,150,30);  
           t2=new JTextField("");  
            t2.setBounds(550,100, 150,30);
	         t3=new JTextField("");  
              t3.setBounds(150,200, 150,30);
	         t4=new JTextField("");  
            t4.setBounds(550,200, 150,30); 
	       t5=new JTextField("");  
          t5.setBounds(150,250, 150,30); 
	     t6=new JTextField("");  
        t6.setBounds(550,250, 150,30);

		 JButton g=new JButton("ADD FLIGHT");
		 //b.setfont(new Font("Arial",Font.ITALIC,15));
			 g.setSize(20,20);
    g.setBounds(550,300,150,50);  
    image.add(g); 
		
		          image.add(t1);
	               image.add(t2);
	                 image.add(t3);
	                  image.add(t4);
	                   image.add(t5);
	                    image.add(t6);

       
	                    

    f.setSize(800,500);  
    f.setLayout(null);  
    f.setVisible(true);  
	f.setResizable(false);
	f.setLocationRelativeTo(null);
	//
		//add action listener for save button
	g.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent evt)
	{
		
        try{  
			//Load the driver class
        Class.forName("oracle.jdbc.driver.OracleDriver");
		// Create con obj
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","pratyusa"); 
		// Create the stmt obj
		
        PreparedStatement ps=con.prepareStatement("insert into newflight values (?,?,?,?,?,?,?,?)");   
        ps.setString(1, t1.getText());
		 ps.setString(2, t2.getText());
		 ps.setString(5, t3.getText()); 
		   ps.setString(6, t4.getText());
		    ps.setString(7, t5.getText());
			 ps.setString(8, t6.getText());
			 ps.setString(3,(String)c.getSelectedItem());
        ps.setString(4,(String)b.getSelectedItem());
			
        ps.executeUpdate();
		ps.close();
		con.close();
		
        JOptionPane.showMessageDialog(null,"Flight Detailed Submitted");
		 total += i;
	    t1.setText("" + total);
		
		
		
		}
    catch( ClassNotFoundException | SQLException p)
    { 
        JOptionPane.showMessageDialog(null,p);
    }
}
	});
}
    
	public static void main(String args[])
	{
		new NewFlight();
	}
    }  