import javax.swing.*;
import java.awt.*;

 class SplashScreen 
{
	JFrame frame;
	JLabel image=new JLabel(new ImageIcon("flight.jpg"));
	JLabel text=new JLabel("Airline Reservation");
	JProgressBar pb=new JProgressBar();
	JLabel message=new JLabel();
	SplashScreen()
	{
		createGUI();
		addImage();
		addText();
		addpb();
		addMessage();
        runningPBar();
	}
	public void createGUI(){
		frame=new JFrame();
		frame.getContentPane().setLayout(null);
		frame.setUndecorated(true);
		frame.setSize(600,400);
		frame.setLocationRelativeTo(null);
		
		//frame.getContentPane().setBackground(Color.pink);
		frame.setVisible(true);
		
	}
	public void addImage(){
	image.setBounds(0,0,600,400);
	image.setLayout(null);
	frame.add(image);
	}
	 public void addMessage()
    {
        message.setBounds(250,320,200,40);
        message.setForeground(Color.pink);
        message.setFont(new Font("arial",Font.BOLD,15));
        image.add(message);
    }
	public void addText(){
	text.setFont(new Font("arial",Font.BOLD,30));
	 text.setForeground(Color.red);
	text.setBounds(140,220,600,40);
	image.add(text);
	}
	public void addpb(){
	pb.setBounds(100,280,400,30);
	pb.setBorderPainted(true);
	pb.setStringPainted(true);
	pb.setBackground(Color.WHITE);
	pb.setForeground(Color.BLACK);
	pb.setValue(0);
	frame.add(pb);
	}
	public void runningPBar(){
        int i=0;

        while( i<=100)
        {
            try{
                Thread.sleep(50);
                pb.setValue(i);
                message.setText("LOADING "+Integer.toString(i)+"%");
                i++;
                if(i==100)
				{
					frame.dispose();
					LoginPage po=new  LoginPage();
                                      po.setVisible(true);
									   po.setSize(600,600);
									   po.setResizable(false);
									  po. setLocationRelativeTo(null);
				}
				
            }catch(Exception e){
                //e.printStackTrace();
            }



        }
    }
}
class SplashScreenPage {
    public static void main(String[] args){
        new SplashScreen();

    }
}

	
	


