import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.sql.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.plaf.metal.MetalIconFactory;
import javax.swing.table.DefaultTableModel;





class  BookingFlight extends JFrame 
{
	JLabel l1;
	JLabel image=new JLabel(new ImageIcon("go.jpg"));
	
	BookingFlight(){
		
   JFrame frame = new JFrame("DATABASE");
       image.setBounds(0,0,1200,600);
	image.setLayout(null);
	frame.add(image);
	   l1=new JLabel("  DATABASE");
	   l1.setForeground(Color.red);
	  l1.setBounds(400,40,200,40);
	   l1.setFont(new Font("RockWell", Font.BOLD, 30));
        image.add(l1);
        
	  ArrayList columnNames = new ArrayList();
	  
        ArrayList data = new ArrayList();



		

		
        try{  
			//Load the driver class
        Class.forName("oracle.jdbc.driver.OracleDriver");
		// Create con obj
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","pratyusa"); 
		// Create the stmt obj
		
       Statement st=con.createStatement();
       ResultSet rs=st.executeQuery("Select *  from TICKETRESERVATION");


	   ResultSetMetaData md = rs.getMetaData();
            int columns = md.getColumnCount();

			 //  Get column names
            for (int i = 1; i <= 10; i++)
            {
                columnNames.add( md.getColumnName(i) );
            }

			 //  Get row data
            while (rs.next())
            {
                ArrayList row = new ArrayList(columns);

                for (int i = 1; i <= 10; i++)
                {
                    row.add( rs.getObject(i) );
                }

                data.add( row );
            }
		  
		}
    catch( ClassNotFoundException | SQLException p)
    { 
        JOptionPane.showMessageDialog(null,p);
    }


	 Vector columnNamesVector = new Vector();
        Vector dataVector = new Vector();

        for (int i = 0; i < data.size(); i++)
        {
            ArrayList subArray = (ArrayList)data.get(i);
            Vector subVector = new Vector();
            for (int j = 0; j < subArray.size(); j++)
            {
                subVector.add(subArray.get(j));
            }
            dataVector.add(subVector);
        }

        for (int i = 0; i < columnNames.size(); i++ )
            columnNamesVector.add(columnNames.get(i));

		 //  Create table with database data    
        JTable table = new JTable(dataVector, columnNamesVector)
			
        {
            public Class getColumnClass(int column)
            {
                for (int row = 0; row < getRowCount(); row++)
                {
                    Object o = getValueAt(row, column);

                    if (o != null)
                    {
                        return o.getClass();
                    }
                }

                return Object.class;
            }
        };

	
		

        JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(50,100,900, 400);
       image.add(scrollPane);
          
		
         
        JPanel buttonPanel = new JPanel();
		

        image.add( buttonPanel);




				

           
		frame.setSize(1000,600);  
        frame.setVisible(true);
		 frame.setLayout(null);    
	frame.setLocationRelativeTo(null);
		frame.setResizable(false); 
		


			


		

	}
	 public static void main(String[] args)
    {
        new BookingFlight();
		
    }
	
}
