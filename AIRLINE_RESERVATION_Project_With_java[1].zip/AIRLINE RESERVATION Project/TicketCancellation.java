import javax.swing.*;    
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class TicketCancellation
{
	TicketCancellation()
 {  

    JFrame f=new JFrame("Ticket Cancellation");  
     JLabel image=new JLabel(new ImageIcon("bhi.jpg"));
	 image.setBounds(0,0,700,500);
	image.setLayout(null);
	f.add(image);
    JLabel l1=new JLabel("Customer_ID");  
    l1.setBounds(50,100,100,30);
	 l1.setFont(new Font("Arial",Font.BOLD,15));
		 l1.setForeground(Color.red);
	JLabel l2=new JLabel("Customer_Name");  
    l2.setBounds(30,150,150,30);
	 l2.setFont(new Font("Arial",Font.BOLD,15));
		 l2.setForeground(Color.red);
	JLabel l3=new JLabel("Flight_ID");  
    l3.setBounds(50,200,100,30);
	 l3.setFont(new Font("Arial",Font.BOLD,15));
		 l3.setForeground(Color.red);
	JLabel l4=new JLabel("Ticket_Number");  
    l4.setBounds(30,250,150,30);
	 l4.setFont(new Font("Arial",Font.BOLD,15));
		 l4.setForeground(Color.red);
	JLabel l5=new JLabel("Seats");  
    l5.setBounds(50,300,100,30);
	 l5.setFont(new Font("Arial",Font.BOLD,15));
		 l5.setForeground(Color.red);
	JLabel l6=new JLabel("TICKET CANCELLATION");  
    l6.setBounds(190,10,400,60);
	 l6.setFont(new Font("Arial",Font.BOLD,30));
		 l6.setForeground(Color.red);
	

	JTextField t1=new JTextField("");
	t1.setBounds(150,100,200,30);
	JTextField t2=new JTextField("");
	t2.setBounds(150,150,200,30);
	JTextField t3=new JTextField("");
	t3.setBounds(150,200,200,30);
	JTextField t4=new JTextField("");
	t4.setBounds(150,250,200,30);
	JTextField t5=new JTextField("");
	t5.setBounds(150,300,200,30);
      image.add(t1);
      image.add(t2);
	  image.add(t3);
	  image.add(t4);
	  image.add(t5);


	JButton b1=new JButton("Cancel");
	b1.setBounds(50,400,400,30);
	JButton b2=new JButton("SEARCH");
	b2.setBounds(500,100,100,30);

	



     image.add(l1);
	 image.add(l2);
	 image.add(l3);
	 image.add(l4);
	 image.add(l5);
	 image.add(l6);
	 image.add(b1);
	 image.add(b2);
    f.setSize(700,500);
	f.setLayout(null);
	f.setVisible(true);
	f.setResizable(false);
	f.setVisible(true);
	f.setLocationRelativeTo(null);//to take frame in middle of window



		//add action listener for save button
	b2.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent evt)
	{
		
        try{  
			//Load the driver class
        Class.forName("oracle.jdbc.driver.OracleDriver");
		// Create con obj
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","pratyusa"); 
		// Create the stmt obj
		Statement st=con.createStatement();
      ResultSet rs=st.executeQuery("Select *  from TICKETRESERVATION WHERE CUST_ID="+Integer.parseInt(t1.getText()));
		
		String s="";
		String e="";
		String v="";
		String i="";
		String o="";
		if(rs.next())
		{
				s=rs.getString(2);
				e=rs.getString(3);
				v=rs.getString(5);
				i=rs.getString(1);
				o=rs.getString(10);
		}
		else{
                    JOptionPane.showMessageDialog(null, "No Data Try another ID");
                }
		t1.setText(s);
		t2.setText(e);
		t3.setText(v);
		t4.setText(i);
		t5.setText(o);
		con.close();
		
		}
		
    catch( ClassNotFoundException | SQLException p)
    { 
        JOptionPane.showMessageDialog(null,p);
    }
}
	});

	b1.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent evt)
	{
		
        try{  
			//Load the driver class
        Class.forName("oracle.jdbc.driver.OracleDriver");
		// Create con obj
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","pratyusa"); 
		// Create the stmt obj
		Statement st=con.createStatement();
		String query="DELETE FROM TICKETRESERVATION where CUST_ID="+Integer.parseInt(t1.getText());
	PreparedStatement ps=con.prepareStatement(query);
	 ps.executeUpdate();
		ps.close(); 


   int a= JOptionPane.showConfirmDialog(f,"Do you want to cancel your ticket ");

		 if (a==JOptionPane.YES_OPTION)
		 {
			 JOptionPane.showMessageDialog(null,"Canceled Successfully");
			 t1.setText("");
			  t2.setText("");
			   t3.setText("");
			    t4.setText("");
				 t5.setText("");
		 }
		
		}
    catch( ClassNotFoundException | SQLException e)
    { 
        JOptionPane.showMessageDialog(null,e);
    }



	}
 });
 }
public static void main(String[] args){
  new TicketCancellation();
}
}  