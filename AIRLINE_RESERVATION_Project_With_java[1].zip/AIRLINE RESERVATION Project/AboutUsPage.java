import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

  class AboutUs  
{
	JFrame frame;

	JLabel text=new JLabel("Airline Reservation System  � 2018");
	JLabel text1=new JLabel("It Is a Standlone Application. Project Made By CSE Student of the Year 2018 ");
	JLabel text2=new JLabel("Project Submitted By:-");
	JLabel text3=new JLabel("BHISHMA DEV BHUYAN ");
	JLabel text4=new JLabel("LIPIKA PRADHAN");
	JLabel text5=new JLabel("ABHISEK PRUSTY");
	JLabel text6=new JLabel("PRATYUSA DWIBEDY");
	
	JLabel image=new JLabel(new ImageIcon("at.png"));
	 
	 
	AboutUs()
	{
		createGUI();
	
		addText();
		addText1();
		addText2();
		addText3();
		addText4();
		addText5();
		addText6();
		addImage();
		
		 
      
	}
	
	
	

	public void createGUI(){
		frame=new JFrame();
		frame.getContentPane().setLayout(null);
		frame.setUndecorated(true);
		frame.setSize(750,250);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setBackground(Color.white);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.addMouseListener(ml);

	}
	public void addImage(){
	image.setBounds(10,40,200,150);
	frame.add(image);
	}
	
	
	
	public void addText(){
	text.setFont(new Font("RockWell",Font.BOLD,30));
	text.setBounds(200,20,600,40);
	frame.add(text);
	}
	public void addText1(){
	text1.setFont(new Font("RockWell",Font.PLAIN,15));
	text1.setBounds(100,210,600,40);
	frame.add(text1);
	}
	public void addText2(){
	text2.setFont(new Font("Helvetica",Font.PLAIN,30));
	text2.setBounds(380,60,500,40);
	frame.add(text2);
	}
	public void addText3(){
	text3.setFont(new Font("arial",Font.BOLD,15));
	text3.setBounds(550,100,200,40);
	frame.add(text3);
	}
	public void addText4(){
	text4.setFont(new Font("arial",Font.BOLD,15));
	text4.setBounds(550,120,200,40);
	frame.add(text4);
	}
	public void addText5(){
	text5.setFont(new Font("arial",Font.BOLD,15));
	text5.setBounds(550,140,200,40);
	frame.add(text5);
	}
	public void addText6(){
	text6.setFont(new Font("arial",Font.BOLD,15));
	text6.setBounds(550,160,200,40);
	frame.add(text6);
	}
 //mouse to click close
	MouseListener ml=new MouseAdapter(){
	 public void mouseClicked(MouseEvent event){
		
	// System.exit(0);
	frame.dispose();
	} };  

	
}
class AboutUsPage {
    public static void main(String[] args){
		
        new AboutUs();

    }
}

	
	


