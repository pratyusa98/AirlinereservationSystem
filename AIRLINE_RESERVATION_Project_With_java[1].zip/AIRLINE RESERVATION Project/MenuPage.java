import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.Calendar;
import java.util.*;
import javax.swing.border.*;

public class  MenuPage extends JFrame implements ActionListener
{
	JMenuItem m1,m2,m3,m4,m5,m6,m7,m8,m10,m11,m12,m13;
	JMenuBar jmb;
	JMenu jm1,jm2,jm3,jm4,jms0,jms1,jms2,jms3,jms4;
	JLabel l1;

	 
	
	JButton jbt0,jbt1,jbt2,jbt3,jbt4,timeField,dateField;
	public MenuPage(){
	
		setTitle("LMSoft");
		
		
	
		
		
		jmb=new JMenuBar();
		//jmb.setBackground(new Color(153,50,204));
		//jmb.setForeground(Color.white);
		//    MANAGE DETAIL
		jm1=new JMenu("       MANAGE DETAIL");
		jm1.setFont(new Font("Times New Roman", Font.PLAIN,15));
		jm1.setPreferredSize(new Dimension(170,30));
		jms1=new JMenu("|");
		jms1.setFont(new Font("Courier New", Font.PLAIN,30));
		jms1.setEnabled(false);
		m1=new JMenuItem("    ADD CUSTOMER");
		m1.setFont(new Font("Times New Roman", Font.BOLD,13));
		m1.setPreferredSize(new Dimension(170,30));
		m2=new JMenuItem("    VIEW CUSTOMER");
		m2.setFont(new Font("Times New Roman", Font.BOLD,13));
		m2.setPreferredSize(new Dimension(170,30));
		m3=new JMenuItem("     ADD FLIGHT");
		m3.setFont(new Font("Times New Roman", Font.BOLD,13));
		m3.setPreferredSize(new Dimension(170,30));
		m13=new JMenuItem("     VIEW FLIGHT");
		m13.setFont(new Font("Times New Roman", Font.BOLD,13));
		m13.setPreferredSize(new Dimension(170,30));
		// TICKET WINDOW
		jm2=new JMenu("TICKET WINDOW");
		jm2.setFont(new Font("Times New Roman", Font.PLAIN,15));
		jm2.setPreferredSize(new Dimension(170,35));
		jms2=new JMenu("|");
		jms2.setFont(new Font("Courier New", Font.PLAIN,30));
		jms2.setEnabled(false);
		m4=new JMenuItem("  TICKET RESERVATION");
		m4.setFont(new Font("Times New Roman", Font.BOLD,13));
		m4.setPreferredSize(new Dimension(170,30));
		m5=new JMenuItem("     TICKET ENQUIRY");
		m5.setFont(new Font("Times New Roman", Font.BOLD,13));
		m5.setPreferredSize(new Dimension(170,30));
		m6=new JMenuItem(" CANCEL TICKET");
		m6.setFont(new Font("Times New Roman", Font.BOLD,13));
		m6.setPreferredSize(new Dimension(170,30));
		// ACCOUNT DETAIL
		jm3=new JMenu("   ACCOUNT DETAIL");
		jm3.setFont(new Font("Times New Roman", Font.PLAIN,15));
		jm3.setPreferredSize(new Dimension(170, 35));
		jms3=new JMenu("|");
		jms3.setFont(new Font("Courier New", Font.PLAIN,30));
		jms3.setEnabled(false);
		m7=new JMenuItem("   BOOKING LIST");
		m7.setFont(new Font("Times New Roman", Font.BOLD,13));
		m7.setPreferredSize(new Dimension(170,30));
		m8=new JMenuItem("    FLIGHT LIST");
		m8.setFont(new Font("Times New Roman", Font.BOLD,13));
		m8.setPreferredSize(new Dimension(170,30));
		
		// HELP
		jm4=new JMenu("         HELP");
		jm4.setFont(new Font("Times New Roman", Font.PLAIN,15));
		jm4.setPreferredSize(new Dimension(170, 35));
		jms4=new JMenu("|");
		jms4.setFont(new Font("Courier New", Font.PLAIN,30));
		jms4.setEnabled(false);
		m10=new JMenuItem("        ABOUT US");
		m10.setFont(new Font("Times New Roman", Font.BOLD,13));
		m10.setPreferredSize(new Dimension(170,30));
		m11=new JMenuItem("        LOGOUT");
		m11.setFont(new Font("Times New Roman", Font.BOLD,13));
		m11.setPreferredSize(new Dimension(170,30));
		
		
		

		
		
		//adding action Listener
		m1.addActionListener(this);
		m2.addActionListener(this);
		m3.addActionListener(this);
		m13.addActionListener(this);
		m4.addActionListener(this);
		m5.addActionListener(this);
		m6.addActionListener(this);
		m7.addActionListener(this);
		m8.addActionListener(this);
		
		m10.addActionListener(this);
		m11.addActionListener(this);
		
		
		
		
		// adding menuItems,menu & menubar to Frame
		jm1.add(m1);jm1.addSeparator();jm1.add(m2);jm1.addSeparator();jm1.add(m3);jm1.addSeparator();jm1.add(m13);
		jmb.add(jm1);
		jmb.add(jms1);
		jm2.add(m4);jm2.addSeparator();jm2.add(m5);jm2.addSeparator();jm2.add(m6);
		jmb.add(jm2);
		jmb.add(jms2);
		jm3.add(m7);jm3.addSeparator();jm3.add(m8);
		jmb.add(jm3);
		jmb.add(jms3);
		jm4.add(m10);jm4.addSeparator();jm4.add(m11);
		jmb.add(jm4);
		jmb.add(jms4);
		
		setJMenuBar(jmb);
		//getRootPane().setDefaultButton(jbt1);


		JLabel background=new JLabel(new ImageIcon("air_4.jpg"));
		 add(background);
		 l1=new JLabel("WELCOME TO OUR AIRLINE",Label.LEFT);

		 l1.setFont(new Font("Sans Serif",Font.BOLD,35));
		 l1.setForeground(new Color(0,0,0,80));
		 l1.setForeground(Color.red);
		l1.setBounds(400,10,500,50);
		 background.add(l1);
		
			//for display date in JFrame
    dateField= new JButton();
    dateField.setFont(new Font("sansserif", Font.PLAIN, 48));
	dateField.setBounds(50,50,257,50);
    dateField.setForeground(Color.magenta);
		dateField. setOpaque(false);
		dateField.setBackground(new Color(0,0,0,80));
        dateField.setBorder(new LineBorder(Color.BLACK));
         background.add( dateField);
javax.swing.Timer r = new javax.swing.Timer(1000, new DateListener());
        r.start();
		 
     

  


//show time in jframe
         timeField = new JButton();
        timeField.setFont(new Font("sansserif", Font.PLAIN, 48));
		 timeField.setForeground(Color.magenta);
		timeField. setOpaque(false);
		timeField.setBounds(970,15,304,50);
		timeField.setBackground(new Color(0,0,0,80));
        timeField.setBorder(new LineBorder(Color.BLACK));
         background.add(timeField);
       
javax.swing.Timer t = new javax.swing.Timer(1000,new ActionListener() {
                  public void actionPerformed(ActionEvent e) {

                  Calendar calendar = new GregorianCalendar();
   String am_pm;


                     Calendar now = Calendar.getInstance();
                      int h = now.get(Calendar.HOUR_OF_DAY);
                      int m = now.get(Calendar.MINUTE);
                      int s = now.get(Calendar.SECOND);


  if( calendar.get( Calendar.AM_PM ) == 0 ){
             am_pm = "AM";

         }
        else{
            am_pm = "PM";

        }   // Code to Determine whether the time is AM or PM

  timeField.setText("" + h + ":" + m + ":" + s + " " + am_pm);
                 
               
           }
              });
        t.start();

		setExtendedState(6); //JFrame.MAXIMIZED_BOTH);
		setVisible(true);
		 setResizable(false);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	}

	class DateListener implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
 
            Calendar now = Calendar.getInstance();
            int month = now.get(Calendar.MONTH);
            int day = now.get(Calendar.DAY_OF_MONTH);
            int year = now.get(Calendar.YEAR);
            dateField.setText("" + day + "/" + "0" + (month + 1) + "/" + year);
 
    	}
    }

	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == m1)
		{
				new AddCustomer();
				//setEnabled(false);
		}
		if(e.getSource() == m2)
		{
				new  ViewCustomer();
				//setEnabled(false);
		}
		if(e.getSource() == m3)
		{
				new NewFlight();
				//setEnabled(false);
		}
		if(e.getSource() == m4)
		{
				new TicetReservation(); 
				//setEnabled(false);
		}
		if(e.getSource() == m5)
		{
				new TicketEnquiry();
				//setEnabled(false);
		}
		if(e.getSource() == m6)
		{
				new TicketCancellation();
				//setEnabled(false);
		}
		if (e.getSource()== m7)
		{
			new BookingFlight();
			//setEnabled(false);
		}
		if(e.getSource() == m8)
		{
			new FlightList();
				//setEnabled(false);
		}
		
		if(e.getSource() == m10)
		{
				new AboutUs();
				//setEnabled(false);
		}
		if(e.getSource() == m11)
		{
			      dispose();
				new LoginPage();
				//setEnabled(false);
		}
		
		if(e.getSource() == m13)
		{
				new ViewFlights();
				//setEnabled(false);
		}
		
		
		
	}
	public static void main(String[] args) 
	{
		new MenuPage();
	}
}