import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class TicketEnquiry
{
	TicketEnquiry()
	{
		JFrame f=new JFrame("Ticket Enquiry");
			JLabel image=new JLabel(new ImageIcon("s.jpg"));
	 image.setBounds(0,0,650,400);
	image.setLayout(null);
	f.add(image);
		JLabel l1,l2,l3,l4,l5,l8,l9,l10;
		l10=new JLabel("TICKET ENQUERY");
		l10.setBounds(230,10,300,80);
		 l10.setFont(new Font("Arial",Font.BOLD,30));
		 l10.setForeground(Color.red);
		
		// l10.setForeground(Color.violet);

		l1=new JLabel("Ticket No");
		l1.setBounds(50,100,100,30);
		 l1.setFont(new Font("Arial",Font.BOLD,15));
		 l1.setForeground(Color.red);
		l2=new JLabel("Customer_ID");
		l2.setBounds(50,150,100,30);
		 l2.setFont(new Font("Arial",Font.BOLD,15));
		 l2.setForeground(Color.red);
		l3=new JLabel("Customer Name");
		l3.setBounds(30,200,150,30);
		 l3.setFont(new Font("Arial",Font.BOLD,15));
		 l3.setForeground(Color.red);
		l4=new JLabel("Flight_ID");
		l4.setBounds(50,250,100,30);
		 l4.setFont(new Font("Arial",Font.BOLD,15));
		 l4.setForeground(Color.red);
		l5=new JLabel("Flight_Name");
		l5.setBounds(350,150,100,30);
		l5.setFont(new Font("Arial",Font.BOLD,15));
		 l5.setForeground(Color.red);
		
		l8=new JLabel("Seats");
		l8.setBounds(350,200,100,30);
		 l8.setFont(new Font("Arial",Font.BOLD,15));
		 l8.setForeground(Color.red);
		l9=new JLabel("Date_Of_JOURNEY");
		l9.setBounds(320,250,150,30);
		 l9.setFont(new Font("Arial",Font.BOLD,15));
		 l9.setForeground(Color.red);
			

			 image.add(l1);
			 image.add(l2);
			 image.add(l3);
			 image.add(l4);
			 image.add(l5);
			
			 image.add(l8);
			 image.add(l9);
			 image.add(l10);

			JTextField t1,t2,t3,t4,t5,t8,t9;

			t1=new JTextField();
			t1.setBounds(150,100,150,30);

			t2=new JTextField();
			t2.setBounds(150,150,150,30);

			t3=new JTextField();
			t3.setBounds(150,200,150,30);

			t4=new JTextField();
			t4.setBounds(150,250,150,30);

			t5=new JTextField();
			t5.setBounds(470,150,150,30);

			
			t8=new JTextField();
			t8.setBounds(470,200,150,30);

			t9=new JTextField();
			t9.setBounds(470,250,150,30);
			
			image.add(t1);
			image.add(t2);
			image.add(t3);
			image.add(t4);
            image.add(t5);
           
            image.add(t8);
            image.add(t9);
			 
			 JButton b=new JButton("SEARCH");
             b.setBounds(350,100,100,30);

			 image.add(b);

            f.setSize(650,400);
			f.setLayout(null);
			f.setVisible(true);
			f.setResizable(false);
			f.setVisible(true);
		    f.setLocationRelativeTo(null);//to take frame in middle of window


			b.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent ett)
	{
		
        try{  
			//Load the driver class
        Class.forName("oracle.jdbc.driver.OracleDriver");
		// Create con obj
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","pratyusa"); 
		// Create the stmt obj
		
       Statement st=con.createStatement();
       ResultSet rs=st.executeQuery("Select *  from TICKETRESERVATION WHERE TICK_NUMBER="+Integer.parseInt(t1.getText()));
		
		String s="";
		String e="";
		String v="";
		String z="";
		String x="";
		//String c="";
		//String b="";
		String n="";
		String t="";
		while(rs.next())
		{
				s=rs.getString(1);
				e=rs.getString(2);
				v=rs.getString(3);
				z=rs.getString(5);
				x=rs.getString(6);
				//c=rs.getString();
				//b=rs.getString(3);
				n=rs.getString(10);
				t=rs.getString(8);
				
				
			}
		t1.setText(s);
		t2.setText(e);
		t3.setText(v);
		t4.setText(z);
		t5.setText(x);
		//t6.setText(o);
		//t7.setText(y);
		t8.setText(n);
		t9.setText(t);
		
			
       
		con.close();
		
        

		}
    catch( ClassNotFoundException | SQLException p)
    { 
        JOptionPane.showMessageDialog(null,p);
    }
}
	});
		
	}
	public static void main(String args[]){
		new TicketEnquiry();
	}
}
